import { useAuth, useOAuth, useSignIn } from '@clerk/clerk-expo'
import { Link, useRouter } from 'expo-router'
import React from 'react'
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'

export default function SignInPage() {
  const { isLoaded, signIn, setActive } = useSignIn()
  const { isSignedIn } = useAuth()
  const { startOAuthFlow: googleAuth } = useOAuth({ strategy: 'oauth_google' })
  const { startOAuthFlow: githubAuth } = useOAuth({ strategy: 'oauth_github' })
  const { startOAuthFlow: appleAuth } = useOAuth({ strategy: 'oauth_apple' })
  const router = useRouter()

  const [showEmailForm, setShowEmailForm] = React.useState(false)
  const [emailAddress, setEmailAddress] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [error, setError] = React.useState('')
  const [loading, setLoading] = React.useState(false)

  if (!isLoaded) {
    return (
      <View style={{ flex: 1, backgroundColor: '#1e4d2b', justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#4ade80" />
      </View>
    )
  }

  if (isSignedIn) {
    router.replace('/')
    return null
  }

  const handleEmailSignIn = async () => {
    setLoading(true)
    setError('')
    try {
      const result = await signIn!.create({
        identifier: emailAddress,
        password,
      })
      if (result.status === 'complete') {
        await setActive!({ session: result.createdSessionId })
        router.replace('/')
      }
    } catch (err: any) {
      setError(err.errors?.[0]?.longMessage || err.errors?.[0]?.message || 'Sign in failed')
    } finally {
      setLoading(false)
    }
  }

  const handleGoogle = async () => {
    try {
      const { createdSessionId, setActive: sa } = await googleAuth()
      if (createdSessionId) {
        await sa!({ session: createdSessionId })
        router.replace('/')
      }
    } catch {
      setError('Google sign in failed')
    }
  }

  const handleGithub = async () => {
    try {
      const { createdSessionId, setActive: sa } = await githubAuth()
      if (createdSessionId) {
        await sa!({ session: createdSessionId })
        router.replace('/')
      }
    } catch {
      setError('GitHub sign in failed')
    }
  }

  const handleApple = async () => {
    try {
      const { createdSessionId, setActive: sa } = await appleAuth()
      if (createdSessionId) {
        await sa!({ session: createdSessionId })
        router.replace('/')
      }
    } catch {
      setError('Apple sign in failed')
    }
  }

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <View style={s.heroSection}>
          <Text style={s.appName}>GROCIFY</Text>
          <Text style={s.tagline}>Plan smarter. Shop happier.</Text>
          <View style={s.heroImageBox}>
            <Image
              source={require('../../../assets/images/grocify-hero.png')}
              style={s.heroImage}
              resizeMode="contain"
            />
          </View>
        </View>

        <View style={s.card}>
          <Text style={s.welcomeLabel}>WELCOME BACK</Text>
          <Text style={s.welcomeSubtitle}>
            Choose a social provider and jump right into your personalized grocery experience.
          </Text>

          {error ? <View style={s.errorBox}><Text style={s.errorText}>{error}</Text></View> : null}

          <View style={s.oauthRow}>
            {Platform.OS === 'ios' && (
              <Pressable style={({ pressed }) => [s.oauthIconBtn, pressed && s.pressed]} onPress={handleApple}>
                <Image source={require('../../../assets/images/apple-logo.png')} style={s.oauthOnlyIcon} />
              </Pressable>
            )}
            <Pressable style={({ pressed }) => [s.oauthIconBtn, pressed && s.pressed]} onPress={handleGoogle}>
              <Image source={require('../../../assets/images/google_logo.png')} style={s.oauthOnlyIcon} />
            </Pressable>
            <Pressable style={({ pressed }) => [s.oauthIconBtn, pressed && s.pressed]} onPress={handleGithub}>
              <Image source={require('../../../assets/images/github-logo.png')} style={s.oauthOnlyIcon} />
            </Pressable>
          </View>

          <View style={s.divider}>
            <View style={s.dividerLine} />
            <Text style={s.dividerText}>or</Text>
            <View style={s.dividerLine} />
          </View>

          {!showEmailForm ? (
            <Pressable style={({ pressed }) => [s.emailToggleBtn, pressed && s.pressed]} onPress={() => setShowEmailForm(true)}>
              <Text style={s.emailToggleText}>Continue with Email</Text>
            </Pressable>
          ) : (
            <View>
              <TextInput
                style={s.input}
                autoCapitalize="none"
                value={emailAddress}
                placeholder="Enter email"
                placeholderTextColor="rgba(255,255,255,0.4)"
                onChangeText={setEmailAddress}
                keyboardType="email-address"
              />
              <TextInput
                style={s.input}
                value={password}
                placeholder="Enter password"
                placeholderTextColor="rgba(255,255,255,0.4)"
                secureTextEntry
                onChangeText={setPassword}
              />
              <Pressable
                style={({ pressed }) => [s.signInBtn, (!emailAddress || !password || loading) && s.btnDisabled, pressed && s.pressed]}
                onPress={handleEmailSignIn}
                disabled={!emailAddress || !password || loading}
              >
                {loading ? <ActivityIndicator color="#1e4d2b" /> : <Text style={s.signInBtnText}>Enter Pantry</Text>}
              </Pressable>
            </View>
          )}

          <Text style={s.terms}>
            By continuing, you agree to our <Text style={s.termsLink}>Terms</Text> and <Text style={s.termsLink}>Privacy Policy</Text>.
          </Text>

          <View style={s.signUpRow}>
            <Text style={s.signUpText}>Do not have an account? </Text>
            <Link href="/(auth)/sign-up"><Text style={s.signUpLink}>Sign up</Text></Link>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const GREEN = '#1e4d2b'
const WHITE = '#ffffff'
const WHITE_DIM = 'rgba(255,255,255,0.7)'
const WHITE_FAINT = 'rgba(255,255,255,0.15)'
const GREEN_CARD = 'rgba(255,255,255,0.08)'

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: GREEN },
  scroll: { flexGrow: 1, paddingBottom: 32 },
  heroSection: { alignItems: 'center', paddingTop: 24, paddingHorizontal: 24 },
  appName: { fontSize: 36, fontWeight: '800', color: WHITE, letterSpacing: 4, marginBottom: 6 },
  tagline: { fontSize: 14, color: WHITE_DIM, marginBottom: 20 },
  heroImageBox: { width: '100%', backgroundColor: 'transparent', alignItems: 'center', marginBottom: 24 },
  heroImage: { width: '100%', height: 240, backgroundColor: 'transparent' },
  card: { marginHorizontal: 16, backgroundColor: GREEN_CARD, borderRadius: 20, padding: 24, borderWidth: 1, borderColor: WHITE_FAINT },
  welcomeLabel: { fontSize: 12, fontWeight: '700', color: WHITE_DIM, letterSpacing: 2, textAlign: 'center', marginBottom: 8 },
  welcomeSubtitle: { fontSize: 13, color: WHITE_DIM, textAlign: 'center', lineHeight: 20, marginBottom: 24 },
  errorBox: { backgroundColor: 'rgba(220,38,38,0.15)', borderWidth: 1, borderColor: 'rgba(220,38,38,0.4)', borderRadius: 10, padding: 10, marginBottom: 14 },
  errorText: { color: '#fca5a5', fontSize: 13, textAlign: 'center' },
  oauthRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 20, marginBottom: 14 },
  oauthIconBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.12)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  pressed: { opacity: 0.75 },
  oauthOnlyIcon: { width: 18, height: 18, resizeMode: 'contain' },
  divider: { flexDirection: 'row', alignItems: 'center', marginVertical: 16 },
  dividerLine: { flex: 1, height: 1, backgroundColor: WHITE_FAINT },
  dividerText: { marginHorizontal: 12, color: WHITE_DIM, fontSize: 12 },
  emailToggleBtn: { borderWidth: 1.5, borderColor: WHITE_FAINT, borderRadius: 14, paddingVertical: 14, alignItems: 'center', marginBottom: 16 },
  emailToggleText: { color: WHITE, fontWeight: '600', fontSize: 15 },
  input: { borderWidth: 1, borderColor: WHITE_FAINT, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 13, fontSize: 15, marginBottom: 12, color: WHITE, backgroundColor: 'rgba(255,255,255,0.08)' },
  signInBtn: { backgroundColor: '#4ade80', borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginBottom: 8 },
  btnDisabled: { opacity: 0.5 },
  signInBtnText: { color: GREEN, fontWeight: '700', fontSize: 15 },
  terms: { fontSize: 12, color: WHITE_DIM, textAlign: 'center', marginTop: 16, lineHeight: 18 },
  termsLink: { color: WHITE, fontWeight: '600', textDecorationLine: 'underline' },
  signUpRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 16 },
  signUpText: { color: WHITE_DIM, fontSize: 14 },
  signUpLink: { color: '#4ade80', fontWeight: '600', fontSize: 14 },
})
